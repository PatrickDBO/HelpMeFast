import { Servicios } from 'src/app/model/servicios';
export class Comentarios{
    idComentarios:number=0;
    opinion:string="";
    numCalificacion: string="";
    servicio:Servicios=new Servicios();
  }