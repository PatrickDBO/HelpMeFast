export class ResultadoMiriam{
servicio:string="";
cantidad_de_anuncio:string="";
precio_minimo:string="";
precio_maximo:string="";
    
}