export class AdultoJoven{
    idAdultoJoven: number=0;
    nombre: string="";
    apellido: string="";
    edad: number=0;
    dni: number=0;
    celular: number=0;
    email: string="";
    direccion: string="";
    username: string="";
    password: string="";
  }
  