export class Distrito{
    idDistrito:number=0;
    nameDistrito:string="";
  }
