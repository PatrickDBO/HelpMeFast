export class Enfermero
{
  idEnfermero: number = 0;
  nameEnfermero:string="";
  dniEnfermero:string="";
  edadEnfermero: number = 0;
  numEnfermero: number = 0;
  emailEnfermero: string="";
  codEnfermero:  string = "";
}
