import {AdultoJoven} from "./adultoJoven";
import {Anuncio} from "./anuncio";

export class Interes{
  idInteres:number=0;
  levelInteres:string="";
  adultoJoven:AdultoJoven=new AdultoJoven();
  anuncio:Anuncio=new Anuncio();
}
